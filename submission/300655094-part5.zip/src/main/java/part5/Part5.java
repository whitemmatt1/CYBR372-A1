package part5;

public class Part5 {
    public static void main(String[] args) {
        int status = CLIApplication.run(args);
        System.exit(status);
    }
    
}
